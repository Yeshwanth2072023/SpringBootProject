package com.yesh.model;

import java.util.Date;
import java.util.Arrays;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Table;

import org.apache.tomcat.util.codec.binary.Base64;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.stereotype.Component;

@Entity
@Table(name = "user")
@Component
public class User {
	@Id // Specifies the primary key of an entity
	@GeneratedValue(strategy = GenerationType.AUTO) //
	private Integer id;
//@Column(name = "uname")
	private String userName;
	private String userPassword;
	private Integer userAge;
	private String userCity;
	private String userGender;
	private String userLanguages;
	private Integer userExperience;
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	private Date userDateOfBirth;
	@Lob
	private byte[] userPic;

	public User() {
		super();
// TODO Auto-generated constructor stub
	}

	public User(Integer id, String userName, String userPassword, Integer userAge, String userCity, String userGender,
			String userLanguages, Integer userExperience, Date userDateOfBirth, byte[] userPic) {
		super();
		this.id = id;
		this.userName = userName;
		this.userPassword = userPassword;
		this.userAge = userAge;
		this.userCity = userCity;
		this.userGender = userGender;
		this.userLanguages = userLanguages;
		this.userExperience = userExperience;
		this.userDateOfBirth = userDateOfBirth;
		this.userPic = userPic;
	}

	public User(Integer id, String userName, String userPassword, Integer userAge, String userCity, String userGender,
			String userLanguages, Integer userExperience, Date userDateOfBirth) {
		super();
		this.id = id;
		this.userName = userName;
		this.userPassword = userPassword;
		this.userAge = userAge;
		this.userCity = userCity;
		this.userGender = userGender;
		this.userLanguages = userLanguages;
		this.userExperience = userExperience;
		this.userDateOfBirth = userDateOfBirth;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getUserPassword() {
		return userPassword;
	}

	public void setUserPassword(String userPassword) {
		this.userPassword = userPassword;
	}

	public Integer getUserAge() {
		return userAge;
	}

	public void setUserAge(Integer userAge) {
		this.userAge = userAge;
	}

	public String getUserCity() {
		return userCity;
	}

	public void setUserCity(String userCity) {
		this.userCity = userCity;
	}

	public String getUserGender() {
		return userGender;
	}

	public void setUserGender(String userGender) {
		this.userGender = userGender;
	}

	public String getUserLanguages() {
		return userLanguages;
	}

	public void setUserLanguages(String userLanguages) {
		this.userLanguages = userLanguages;
	}

	public Integer getUserExperience() {
		return userExperience;
	}

	public void setUserExperience(Integer userExperience) {
		this.userExperience = userExperience;
	}

	public Date getUserDateOfBirth() {
		return userDateOfBirth;
	}

	public void setUserDateOfBirth(Date userDateOfBirth) {
		this.userDateOfBirth = userDateOfBirth;
	}

	public byte[] getUserPic() {
		return userPic;
	}

	public void setUserPic(byte[] userPic) {
		this.userPic = userPic;
	}

	@Override
	public String toString() {
		return "User [id=" + id + ", userName=" + userName + ", userPassword=" + userPassword + ", userAge=" + userAge
				+ ", userCity=" + userCity + ", userGender=" + userGender + ", userLanguages=" + userLanguages
				+ ", userExperience=" + userExperience + ", userDateOfBirth=" + userDateOfBirth + ", userPic=" + Arrays.toString(userPic) + "]";
	}

	public String getUserPicture() {
		return Base64.encodeBase64String(userPic);
	}
}